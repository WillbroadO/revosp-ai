(()=>{var e={};e.id=941,e.ids=[941],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19314:(e,t,a)=>{"use strict";a.r(t),a.d(t,{patchFetch:()=>A,routeModule:()=>c,serverHooks:()=>d,workAsyncStorage:()=>T,workUnitAsyncStorage:()=>R});var r={};a.r(r),a.d(r,{GET:()=>l,POST:()=>u});var s=a(96559),n=a(48088),i=a(37719),o=a(32190),E=a(84372);async function l(e){try{let t=E.B.extractTenantId(e);if(!t)return o.NextResponse.json({error:"Tenant ID required"},{status:400});let a=new URL(e.url),r=a.searchParams.get("segment"),s=a.searchParams.get("risk"),n={};r&&"all"!==r&&(n.segment=r),s&&"all"!==s&&(n.riskLevel=s);let i=await E.B.getCustomers(t,n);return o.NextResponse.json({success:!0,customers:i,tenant:t,total:i.length})}catch(e){return console.error("Error fetching customers:",e),o.NextResponse.json({error:"Failed to fetch customers",details:e.message},{status:500})}}async function u(e){try{let t=E.B.extractTenantId(e);if(!t)return o.NextResponse.json({error:"Tenant ID required"},{status:400});let{name:a,email:r,company_name:s,arr:n,health_score:i,churn_risk:l,segment:u}=await e.json();if(!a||!r)return o.NextResponse.json({error:"Name and email are required"},{status:400});let c=await E.B.createCustomer(t,{name:a,email:r,company_name:s,arr:parseFloat(n)||0,health_score:parseInt(i)||100,churn_risk:parseInt(l)||0,segment:u||"smb"});return o.NextResponse.json({success:!0,customer:c,message:"Customer created successfully"})}catch(e){if(console.error("Error creating customer:",e),e.message.includes("unique constraint"))return o.NextResponse.json({error:"Customer with this email already exists for this tenant"},{status:409});return o.NextResponse.json({error:"Failed to create customer",details:e.message},{status:500})}}let c=new s.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/customers/route",pathname:"/api/customers",filename:"route",bundlePath:"app/api/customers/route"},resolvedPagePath:"/app/nextjs-revos/src/app/api/customers/route.js",nextConfigOutput:"",userland:r}),{workAsyncStorage:T,workUnitAsyncStorage:R,serverHooks:d}=c;function A(){return(0,i.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:R})}},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47990:()=>{},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},81630:e=>{"use strict";e.exports=require("http")},84372:(e,t,a)=>{"use strict";a.d(t,{B:()=>s});var r=a(83376);class s{static async initializeDatabase(){try{return await (0,r.ll)`
        CREATE TABLE IF NOT EXISTS tenants (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) UNIQUE NOT NULL,
          name VARCHAR(255) NOT NULL,
          subdomain VARCHAR(100) UNIQUE,
          plan VARCHAR(50) DEFAULT 'starter',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          settings JSONB DEFAULT '{}'
        )
      `,await (0,r.ll)`
        CREATE TABLE IF NOT EXISTS customers (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL,
          company_name VARCHAR(255),
          arr DECIMAL(12,2) DEFAULT 0,
          health_score INTEGER DEFAULT 100,
          churn_risk INTEGER DEFAULT 0,
          segment VARCHAR(50) DEFAULT 'smb',
          status VARCHAR(50) DEFAULT 'active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT unique_email_per_tenant UNIQUE(tenant_id, email)
        )
      `,await (0,r.ll)`
        CREATE TABLE IF NOT EXISTS revenue_data (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          customer_id INTEGER REFERENCES customers(id),
          amount DECIMAL(12,2) NOT NULL,
          date DATE NOT NULL,
          segment VARCHAR(50),
          source VARCHAR(100),
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,r.ll)`
        CREATE TABLE IF NOT EXISTS tasks (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          title VARCHAR(500) NOT NULL,
          description TEXT,
          assignee VARCHAR(255),
          status VARCHAR(50) DEFAULT 'pending',
          priority VARCHAR(20) DEFAULT 'medium',
          due_date DATE,
          ai_generated BOOLEAN DEFAULT false,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,r.ll)`
        CREATE TABLE IF NOT EXISTS waitlist (
          id SERIAL PRIMARY KEY,
          full_name VARCHAR(255) NOT NULL,
          work_email VARCHAR(255) UNIQUE NOT NULL,
          company VARCHAR(255) NOT NULL,
          role VARCHAR(255),
          industry VARCHAR(100),
          status VARCHAR(50) DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,r.ll)`ALTER TABLE customers ENABLE ROW LEVEL SECURITY`,await (0,r.ll)`ALTER TABLE revenue_data ENABLE ROW LEVEL SECURITY`,await (0,r.ll)`ALTER TABLE tasks ENABLE ROW LEVEL SECURITY`,await (0,r.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_customers 
        ON customers FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,r.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_revenue 
        ON revenue_data FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,r.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_tasks 
        ON tasks FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_customers_tenant ON customers(tenant_id)`,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_customers_health ON customers(health_score)`,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_revenue_tenant ON revenue_data(tenant_id)`,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_revenue_date ON revenue_data(date)`,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_tasks_tenant ON tasks(tenant_id)`,await (0,r.ll)`CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)`,console.log("✅ Database initialized successfully with multi-tenant security"),!0}catch(e){throw console.error("❌ Database initialization error:",e),e}}static async setTenantContext(e){if(!e)throw Error("Tenant ID is required");await (0,r.ll)`SELECT set_config('app.current_tenant_id', ${e}, true)`}static async getCustomers(e,t={}){await this.setTenantContext(e);let a=(0,r.ll)`
      SELECT * FROM customers 
      WHERE tenant_id = ${e}
    `;if(t.segment&&"all"!==t.segment&&(a=(0,r.ll)`${a} AND segment = ${t.segment}`),t.riskLevel&&"all"!==t.riskLevel){let[e,s]={low:[0,25],medium:[26,65],high:[66,100]}[t.riskLevel]||[0,100];a=(0,r.ll)`${a} AND churn_risk BETWEEN ${e} AND ${s}`}return a=(0,r.ll)`${a} ORDER BY health_score DESC, created_at DESC`,(await a).rows}static async createCustomer(e,t){await this.setTenantContext(e);let{name:a,email:s,company_name:n,arr:i=0,health_score:o=100,churn_risk:E=0,segment:l="smb"}=t;return(await (0,r.ll)`
      INSERT INTO customers (tenant_id, name, email, company_name, arr, health_score, churn_risk, segment)
      VALUES (${e}, ${a}, ${s}, ${n}, ${i}, ${o}, ${E}, ${l})
      RETURNING *
    `).rows[0]}static async getRevenueData(e,t={}){await this.setTenantContext(e);let a=(0,r.ll)`
      SELECT * FROM revenue_data 
      WHERE tenant_id = ${e}
    `;return t.start&&t.end&&(a=(0,r.ll)`${a} AND date BETWEEN ${t.start} AND ${t.end}`),a=(0,r.ll)`${a} ORDER BY date DESC`,(await a).rows}static async createRevenueEntry(e,t){await this.setTenantContext(e);let{customer_id:a,amount:s,date:n,segment:i,source:o="manual"}=t;return(await (0,r.ll)`
      INSERT INTO revenue_data (tenant_id, customer_id, amount, date, segment, source)
      VALUES (${e}, ${a}, ${s}, ${n}, ${i}, ${o})
      RETURNING *
    `).rows[0]}static async getTasks(e,t={}){await this.setTenantContext(e);let a=(0,r.ll)`
      SELECT * FROM tasks 
      WHERE tenant_id = ${e}
    `;return t.status&&"all"!==t.status&&(a=(0,r.ll)`${a} AND status = ${t.status}`),void 0!==t.ai_generated&&(a=(0,r.ll)`${a} AND ai_generated = ${t.ai_generated}`),a=(0,r.ll)`${a} ORDER BY 
      CASE priority 
        WHEN 'high' THEN 1 
        WHEN 'medium' THEN 2 
        WHEN 'low' THEN 3 
      END, 
      created_at DESC`,(await a).rows}static async createTask(e,t){await this.setTenantContext(e);let{title:a,description:s,assignee:n,status:i="pending",priority:o="medium",due_date:E,ai_generated:l=!1}=t;return(await (0,r.ll)`
      INSERT INTO tasks (tenant_id, title, description, assignee, status, priority, due_date, ai_generated)
      VALUES (${e}, ${a}, ${s}, ${n}, ${i}, ${o}, ${E}, ${l})
      RETURNING *
    `).rows[0]}static async addToWaitlist(e){let{full_name:t,work_email:a,company:s,role:n,industry:i}=e;try{return(await (0,r.ll)`
        INSERT INTO waitlist (full_name, work_email, company, role, industry)
        VALUES (${t}, ${a}, ${s}, ${n}, ${i})
        RETURNING *
      `).rows[0]}catch(e){if(e.message.includes("unique constraint"))throw Error("Email already registered");throw e}}static async getWaitlistEntries(){return(await (0,r.ll)`
      SELECT * FROM waitlist 
      ORDER BY created_at DESC
    `).rows}static async initializeTenant(e,t){try{for(let a of(await (0,r.ll)`
        INSERT INTO tenants (tenant_id, name, subdomain, plan)
        VALUES (${e}, ${t.name}, ${t.subdomain||e}, ${t.plan||"starter"})
        ON CONFLICT (tenant_id) DO NOTHING
      `,await this.setTenantContext(e),[{name:"John Smith",email:"john@example.com",company_name:"Example Corp",arr:5e4,health_score:85,churn_risk:15,segment:"mid-market"},{name:"Sarah Johnson",email:"sarah@demo.com",company_name:"Demo Inc",arr:12e4,health_score:92,churn_risk:8,segment:"enterprise"}]))await this.createCustomer(e,a);return console.log(`✅ Tenant ${e} initialized with sample data`),!0}catch(t){throw console.error(`❌ Error initializing tenant ${e}:`,t),t}}static async getTenant(e){return(await (0,r.ll)`
      SELECT * FROM tenants WHERE tenant_id = ${e}
    `).rows[0]}static extractTenantId(e){let t=e.headers.get("x-tenant-id");if(t)return t;let a=e.headers.get("host");if(a){let e=a.split(".")[0],t={"urban-ark":"urban_ark",caalvert:"caalvert_enterprises",brandme:"brandme_kenya"};if(t[e])return t[e]}return"demo_tenant"}}s.initializeDatabase().catch(console.error)},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[447,580,376],()=>a(19314));module.exports=r})();