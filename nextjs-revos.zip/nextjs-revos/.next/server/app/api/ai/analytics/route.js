(()=>{var e={};e.id=541,e.ids=[541],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4434:(e,t,a)=>{"use strict";a.r(t),a.d(t,{patchFetch:()=>y,routeModule:()=>p,serverHooks:()=>m,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>d});var n={};a.r(n),a.d(n,{POST:()=>l});var r=a(96559),i=a(48088),s=a(37719),o=a(32190);let c="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";async function l(e){try{let{query:t,data_context:a}=await e.json();if(!t)return o.NextResponse.json({error:"Query is required"},{status:400});try{if(c){let e=`
You are RevOS AI Analytics Assistant. Analyze this revenue operations query and provide data-driven insights.

Current Revenue Data Context:
- Monthly Revenue: $2.4M (up 23% vs last month)
- Pipeline Health: 87% (Enterprise: 87%, Mid-Market: 82%, SMB: 69%)
- Active Deals: 156 (up 8%)
- Average Sales Cycle: 42 days (down 15%)
- Top Risk Accounts: Global Systems (65% churn risk), Scale Dynamics (35% churn risk)
- Expansion Opportunities: BrandMe Kenya (80% expansion score), Urban Ark (45% expansion score)

Query: ${t}

Provide specific, actionable analytics insights:
`,a=await fetch("https://api-inference.huggingface.co/models/google/flan-t5-xl",{method:"POST",headers:{Authorization:`Bearer ${c}`,"Content-Type":"application/json"},body:JSON.stringify({inputs:e,parameters:{max_new_tokens:400,temperature:.6,do_sample:!0,return_full_text:!1}})});if(a.ok){let e=await a.json(),n="Unable to analyze this query.";return Array.isArray(e)&&e.length>0&&(n=e[0].generated_text||n),o.NextResponse.json({response:n.trim(),query:t,model:"google/flan-t5-xl",timestamp:new Date().toISOString(),suggestions:["Show me pipeline health by segment","What are the top expansion opportunities?","Analyze churn risk factors","Revenue forecast accuracy"]})}}}catch(e){console.log("Using fallback analytics response:",e.message)}let n=function(e){let t=e.toLowerCase();return t.includes("segment")||t.includes("pipeline")?`**Pipeline Health by Segment Analysis**:

📊 **Enterprise Segment**: 87% Health Score
   • Conversion Rate: 23% (15% above average)
   • Avg Deal Size: $850K
   • Sales Cycle: 38 days
   • Revenue Impact: $12.3M total pipeline

📈 **Mid-Market Segment**: 82% Health Score  
   • Conversion Rate: 19% (solid performance)
   • Avg Deal Size: $420K
   • Sales Cycle: 45 days
   • Expansion Potential: 60% of accounts

📉 **SMB Segment**: 69% Health Score ⚠️
   • Conversion Rate: 14% (below target)
   • Avg Deal Size: $150K
   • Sales Cycle: 52 days (8 days longer)
   • Action Needed: Process optimization

**Recommendation**: Reallocate 20% of SMB resources to Enterprise segment for maximum Q4 impact.`:t.includes("expansion")||t.includes("upsell")?`**Top Expansion Opportunities Analysis**:

🚀 **Immediate Opportunities** ($2.3M Potential):

1. **BrandMe Kenya** - 80% Expansion Score
   • Current ARR: $290K → Potential: $580K
   • Usage: 95% of features activated
   • Health Score: 90/100
   • Action: Present enterprise plan upgrade

2. **Urban Ark** - 45% Expansion Score  
   • Current ARR: $850K → Potential: $1.2M
   • Recent feature adoption: +40%
   • Team growth: 25% headcount increase
   • Action: Discuss additional licenses

3. **Caalvert Enterprises** - 60% Expansion Score
   • Current ARR: $420K → Potential: $650K  
   • API usage: 300% increase
   • New department interest: Marketing team
   • Action: Demo advanced automation features

**Timing**: Q4 is optimal for enterprise upgrades due to budget cycles.`:t.includes("churn")||t.includes("risk")?`**Churn Risk Factor Analysis**:

🔴 **High-Risk Indicators Detected**:

**Primary Risk Factors**:
1. **Low Product Usage** (<50% feature adoption)
   • Accounts affected: 3 (Global Systems, Scale Dynamics)
   • Risk level: 65% and 35% respectively
   
2. **Support Ticket Volume** (+40% increase)
   • Pattern: Technical integration issues
   • Response time impact on satisfaction

3. **Engagement Decline** (>5 days since last activity)
   • Early warning signal for churn
   • Requires immediate CSM intervention

**Protective Factors**:
✅ **Feature X Usage**: 45% lower churn rate
✅ **Regular QBRs**: 60% retention improvement  
✅ **Executive Engagement**: 80% renewal probability

**Action Plan**: Implement weekly health score monitoring and proactive outreach for scores <70.`:t.includes("forecast")||t.includes("accuracy")?`**Revenue Forecast Accuracy Analysis**:

🎯 **Current Forecast Performance**:
   • Model Accuracy: 94.2%
   • Q3 Actual vs Predicted: 96% accuracy
   • Monthly Variance: \xb13.2% average

📊 **Q4 2024 Forecast**:
   • Conservative: $8.2M (25% probability)  
   • Realistic: $8.8M (50% probability)
   • Optimistic: $9.5M (25% probability)
   • Confidence Interval: 92%

🔍 **Accuracy Drivers**:
   • Enterprise pipeline visibility: 95%
   • Historical pattern matching: 87%
   • External factor integration: 82%

⚠️ **Risk Factors**:
   • Market conditions: -3% impact
   • Competition: -2% impact
   • Economic headwinds: -5% potential impact

**Model Recommendation**: 89% probability of achieving $8.8M target based on current pipeline momentum.`:`**Comprehensive Revenue Analytics**:

📊 **Key Performance Indicators**:
   • Revenue Growth: +23% MoM ($2.4M current)
   • Pipeline Conversion: 87% health score
   • Customer Acquisition: +8% active deals (156 total)
   • Sales Efficiency: 42-day cycle (-15% improvement)

🎯 **Segment Performance**:
   • Enterprise: Leading with 87% health, $850K avg deal
   • Mid-Market: Solid 82% health, expansion opportunities
   • SMB: Underperforming at 69%, needs optimization

⚡ **Growth Drivers**:
   • Feature adoption up 40% across Enterprise accounts
   • Customer success initiatives reducing churn by 25%
   • Sales team exceeding quotas by average 8%

💡 **Strategic Recommendations**:
1. Double down on Enterprise segment success factors
2. Accelerate mid-market expansion initiatives  
3. Optimize SMB acquisition and onboarding process

**Next Analysis**: Which specific metric would you like me to dive deeper into?`}(t);return o.NextResponse.json({response:n,query:t,model:"fallback",timestamp:new Date().toISOString(),suggestions:["Show me pipeline health by segment","What are the top expansion opportunities?","Analyze churn risk factors","Revenue forecast accuracy"]})}catch(e){return console.error("Error in AI analytics:",e),o.NextResponse.json({error:"Internal server error"},{status:500})}}let p=new r.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/ai/analytics/route",pathname:"/api/ai/analytics",filename:"route",bundlePath:"app/api/ai/analytics/route"},resolvedPagePath:"/app/nextjs-revos/src/app/api/ai/analytics/route.js",nextConfigOutput:"",userland:n}),{workAsyncStorage:u,workUnitAsyncStorage:d,serverHooks:m}=p;function y(){return(0,s.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:d})}},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),n=t.X(0,[447,580],()=>a(4434));module.exports=n})();