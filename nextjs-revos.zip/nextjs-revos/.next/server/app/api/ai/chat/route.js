(()=>{var e={};e.id=337,e.ids=[337],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},84306:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>h,routeModule:()=>l,serverHooks:()=>g,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>d});var n={};r.r(n),r.d(n,{POST:()=>p});var s=r(96559),a=r(48088),o=r(37719),i=r(32190);let c="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";async function u(e,t){if(!c)throw Error("Hugging Face API token not configured");let r=await fetch(`https://api-inference.huggingface.co/models/${e}`,{method:"POST",headers:{Authorization:`Bearer ${c}`,"Content-Type":"application/json"},body:JSON.stringify(t)});if(!r.ok)throw Error(`Hugging Face API error: ${r.statusText}`);return r.json()}async function p(e){try{let{message:t,context:r}=await e.json();if(!t)return i.NextResponse.json({error:"Message is required"},{status:400});let n=function(e,t=""){return`
You are RevOS AI, an expert Revenue Operations assistant. You specialize in:
- Revenue forecasting and pipeline analysis
- Sales operations optimization  
- Marketing operations and lead management
- Customer success and churn prevention
- Business intelligence and analytics
- CRM and data integration

Revenue Operations terminology you understand:
- ARR (Annual Recurring Revenue), MRR (Monthly Recurring Revenue)
- CAC (Customer Acquisition Cost), LTV (Lifetime Value)
- Pipeline velocity, conversion rates, win rates
- Churn rate, expansion revenue, upselling
- Lead scoring, qualification, nurturing
- Sales cycle, quota attainment, territory management
- Customer health scores, NPS, engagement metrics

Provide specific, actionable insights based on revenue operations best practices.
Keep responses concise but comprehensive.

Context: ${t}

User Question: ${e}

RevOS AI Response:`}(t,r||"");try{let e=await u("google/flan-t5-xl",{inputs:n,parameters:{max_new_tokens:300,temperature:.7,do_sample:!0,return_full_text:!1}}),t="I apologize, but I couldn't generate a response. Please try rephrasing your question.";return Array.isArray(e)&&e.length>0&&(t=e[0].generated_text||t),i.NextResponse.json({response:t.trim(),model:"google/flan-t5-xl",timestamp:new Date().toISOString()})}catch(r){console.log("Using fallback response due to AI API error:",r.message);let e=function(e){let t=e.toLowerCase();return t.includes("revenue")||t.includes("forecast")?`**Revenue Analysis**: Based on your current data trends:

🔍 **Current Performance**: Monthly revenue of $2.4M shows strong 23% growth momentum
📊 **Q4 Forecast**: 92% confidence in hitting $8.8M target based on pipeline health  
⚡ **Key Driver**: Enterprise segment showing 15% higher conversion rates
💡 **Recommendation**: Focus resources on Enterprise segment for maximum Q4 impact

**Next Steps**: Would you like me to analyze specific segments or time periods?`:t.includes("pipeline")||t.includes("health")?`**Pipeline Health Analysis**:

📈 **Overall Health Score**: 87% (Excellent)
🎯 **By Segment**: 
   • Enterprise: 87% (Strong)
   • Mid-Market: 82% (Good)  
   • SMB: 69% (Needs Attention)

⚠️ **Risk Factors**: SMB segment velocity slower by 8 days
💡 **Opportunity**: Mid-market shows 60% expansion potential

**Action Items**: Review SMB qualification process and accelerate mid-market expansion.`:t.includes("churn")||t.includes("risk")?`**Customer Risk Analysis**:

🔴 **High Risk Accounts** (3 accounts, $830K ARR):
   • Global Systems: 65% churn risk - Immediate intervention needed
   • Scale Dynamics: 35% churn risk - Schedule health check
   • TechStart Inc: 28% churn risk - Renewal conversation pending

💚 **Success Factors**: Accounts with Feature X usage show 45% lower churn
🎯 **Prevention Strategy**: Implement proactive customer success outreach

**Immediate Actions**: Executive review for Global Systems, CSM check-ins for others.`:t.includes("expansion")||t.includes("upsell")?`**Expansion Opportunities**:

🚀 **Top Expansion Targets**:
   • BrandMe Kenya: 80% expansion score - Ready for upgrade discussion
   • Urban Ark: 45% expansion score - Strong product adoption
   • Caalvert Enterprises: 60% expansion potential - Feature usage growing

📊 **Expansion Indicators**:
   • Product usage >80%: Strong expansion signal
   • Feature adoption rate: +25% month-over-month
   • Support ticket sentiment: Positive trend

💰 **Revenue Impact**: $2.3M potential expansion revenue in Q4`:t.includes("team")||t.includes("performance")?`**Team Performance Analysis**:

🎯 **Sales Performance**:
   • Quota Attainment: 108% average (8% above target)
   • Top Performers: Sarah Wilson (Enterprise), Mike Chen (Mid-Market)
   • Avg Sales Cycle: 42 days (15% improvement)

📈 **Key Metrics**:
   • Win Rate: 23% (up from 19%)
   • Average Deal Size: $156K (+12%)
   • Pipeline Velocity: +18% this quarter

💡 **Optimization**: Replicate top performer strategies across team`:`**RevOS AI Insights**:

Based on your revenue operations data, here are key findings:

🔍 **Current Performance**: 
   • Monthly Revenue: $2.4M (+23% growth)
   • Pipeline Health: 87% (strong across segments)
   • Active Deals: 156 (+8% increase)

⚡ **Key Opportunities**:
   • Enterprise segment outperforming by 15%
   • Mid-market expansion potential: $2.3M
   • Customer success initiatives reducing churn

💡 **Strategic Recommendations**:
   1. Reallocate resources to Enterprise segment
   2. Accelerate mid-market expansion programs  
   3. Implement proactive customer success for at-risk accounts

**What specific area would you like me to analyze deeper?**`}(t);return i.NextResponse.json({response:e,model:"fallback",timestamp:new Date().toISOString()})}}catch(e){return console.error("Error in AI chat:",e),i.NextResponse.json({error:"Internal server error"},{status:500})}}let l=new s.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/ai/chat/route",pathname:"/api/ai/chat",filename:"route",bundlePath:"app/api/ai/chat/route"},resolvedPagePath:"/app/nextjs-revos/src/app/api/ai/chat/route.js",nextConfigOutput:"",userland:n}),{workAsyncStorage:m,workUnitAsyncStorage:d,serverHooks:g}=l;function h(){return(0,o.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:d})}},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[447,580],()=>r(84306));module.exports=n})();