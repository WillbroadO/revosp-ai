(()=>{var t={};t.id=225,t.ids=[225],t.modules={3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19225:(t,e,a)=>{"use strict";a.r(e),a.d(e,{patchFetch:()=>A,routeModule:()=>T,serverHooks:()=>d,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>R});var s={};a.r(s),a.d(s,{GET:()=>u,POST:()=>o});var r=a(96559),n=a(48088),i=a(37719),l=a(32190),E=a(84372);async function o(t){try{let{fullName:e,workEmail:a,company:s,role:r,industry:n,timestamp:i}=await t.json();if(!e||!a||!s||!r||!n)return l.NextResponse.json({success:!1,message:"All fields are required"},{status:400});if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a))return l.NextResponse.json({success:!1,message:"Invalid email format"},{status:400});let o=await E.B.addToWaitlist({full_name:e,work_email:a,company:s,role:r,industry:n});return console.log(`✅ New waitlist entry: ${a} from ${s}`),l.NextResponse.json({success:!0,message:"Successfully added to waitlist",id:o.id})}catch(t){if(console.error("❌ Error processing waitlist entry:",t),t.message.includes("Email already registered"))return l.NextResponse.json({success:!1,message:"This email is already registered"},{status:409});return l.NextResponse.json({success:!1,message:"Error processing waitlist entry"},{status:500})}}async function u(t){try{let t=await E.B.getWaitlistEntries();return l.NextResponse.json({success:!0,entries:t,total:t.length})}catch(t){return console.error("❌ Error fetching waitlist:",t),l.NextResponse.json({error:"Failed to fetch waitlist entries"},{status:500})}}let T=new r.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/waitlist/route",pathname:"/api/waitlist",filename:"route",bundlePath:"app/api/waitlist/route"},resolvedPagePath:"/app/nextjs-revos/src/app/api/waitlist/route.js",nextConfigOutput:"",userland:s}),{workAsyncStorage:c,workUnitAsyncStorage:R,serverHooks:d}=T;function A(){return(0,i.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:R})}},21820:t=>{"use strict";t.exports=require("os")},27910:t=>{"use strict";t.exports=require("stream")},29021:t=>{"use strict";t.exports=require("fs")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:t=>{"use strict";t.exports=require("path")},34631:t=>{"use strict";t.exports=require("tls")},44870:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47990:()=>{},55511:t=>{"use strict";t.exports=require("crypto")},55591:t=>{"use strict";t.exports=require("https")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:t=>{"use strict";t.exports=require("zlib")},78335:()=>{},79428:t=>{"use strict";t.exports=require("buffer")},79551:t=>{"use strict";t.exports=require("url")},81630:t=>{"use strict";t.exports=require("http")},84372:(t,e,a)=>{"use strict";a.d(e,{B:()=>r});var s=a(83376);class r{static async initializeDatabase(){try{return await (0,s.ll)`
        CREATE TABLE IF NOT EXISTS tenants (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) UNIQUE NOT NULL,
          name VARCHAR(255) NOT NULL,
          subdomain VARCHAR(100) UNIQUE,
          plan VARCHAR(50) DEFAULT 'starter',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          settings JSONB DEFAULT '{}'
        )
      `,await (0,s.ll)`
        CREATE TABLE IF NOT EXISTS customers (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL,
          company_name VARCHAR(255),
          arr DECIMAL(12,2) DEFAULT 0,
          health_score INTEGER DEFAULT 100,
          churn_risk INTEGER DEFAULT 0,
          segment VARCHAR(50) DEFAULT 'smb',
          status VARCHAR(50) DEFAULT 'active',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          CONSTRAINT unique_email_per_tenant UNIQUE(tenant_id, email)
        )
      `,await (0,s.ll)`
        CREATE TABLE IF NOT EXISTS revenue_data (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          customer_id INTEGER REFERENCES customers(id),
          amount DECIMAL(12,2) NOT NULL,
          date DATE NOT NULL,
          segment VARCHAR(50),
          source VARCHAR(100),
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,s.ll)`
        CREATE TABLE IF NOT EXISTS tasks (
          id SERIAL PRIMARY KEY,
          tenant_id VARCHAR(100) NOT NULL,
          title VARCHAR(500) NOT NULL,
          description TEXT,
          assignee VARCHAR(255),
          status VARCHAR(50) DEFAULT 'pending',
          priority VARCHAR(20) DEFAULT 'medium',
          due_date DATE,
          ai_generated BOOLEAN DEFAULT false,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,s.ll)`
        CREATE TABLE IF NOT EXISTS waitlist (
          id SERIAL PRIMARY KEY,
          full_name VARCHAR(255) NOT NULL,
          work_email VARCHAR(255) UNIQUE NOT NULL,
          company VARCHAR(255) NOT NULL,
          role VARCHAR(255),
          industry VARCHAR(100),
          status VARCHAR(50) DEFAULT 'pending',
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `,await (0,s.ll)`ALTER TABLE customers ENABLE ROW LEVEL SECURITY`,await (0,s.ll)`ALTER TABLE revenue_data ENABLE ROW LEVEL SECURITY`,await (0,s.ll)`ALTER TABLE tasks ENABLE ROW LEVEL SECURITY`,await (0,s.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_customers 
        ON customers FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,s.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_revenue 
        ON revenue_data FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,s.ll)`
        CREATE POLICY IF NOT EXISTS tenant_isolation_tasks 
        ON tasks FOR ALL 
        USING (tenant_id = current_setting('app.current_tenant_id', true))
      `,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_customers_tenant ON customers(tenant_id)`,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_customers_health ON customers(health_score)`,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_revenue_tenant ON revenue_data(tenant_id)`,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_revenue_date ON revenue_data(date)`,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_tasks_tenant ON tasks(tenant_id)`,await (0,s.ll)`CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)`,console.log("✅ Database initialized successfully with multi-tenant security"),!0}catch(t){throw console.error("❌ Database initialization error:",t),t}}static async setTenantContext(t){if(!t)throw Error("Tenant ID is required");await (0,s.ll)`SELECT set_config('app.current_tenant_id', ${t}, true)`}static async getCustomers(t,e={}){await this.setTenantContext(t);let a=(0,s.ll)`
      SELECT * FROM customers 
      WHERE tenant_id = ${t}
    `;if(e.segment&&"all"!==e.segment&&(a=(0,s.ll)`${a} AND segment = ${e.segment}`),e.riskLevel&&"all"!==e.riskLevel){let[t,r]={low:[0,25],medium:[26,65],high:[66,100]}[e.riskLevel]||[0,100];a=(0,s.ll)`${a} AND churn_risk BETWEEN ${t} AND ${r}`}return a=(0,s.ll)`${a} ORDER BY health_score DESC, created_at DESC`,(await a).rows}static async createCustomer(t,e){await this.setTenantContext(t);let{name:a,email:r,company_name:n,arr:i=0,health_score:l=100,churn_risk:E=0,segment:o="smb"}=e;return(await (0,s.ll)`
      INSERT INTO customers (tenant_id, name, email, company_name, arr, health_score, churn_risk, segment)
      VALUES (${t}, ${a}, ${r}, ${n}, ${i}, ${l}, ${E}, ${o})
      RETURNING *
    `).rows[0]}static async getRevenueData(t,e={}){await this.setTenantContext(t);let a=(0,s.ll)`
      SELECT * FROM revenue_data 
      WHERE tenant_id = ${t}
    `;return e.start&&e.end&&(a=(0,s.ll)`${a} AND date BETWEEN ${e.start} AND ${e.end}`),a=(0,s.ll)`${a} ORDER BY date DESC`,(await a).rows}static async createRevenueEntry(t,e){await this.setTenantContext(t);let{customer_id:a,amount:r,date:n,segment:i,source:l="manual"}=e;return(await (0,s.ll)`
      INSERT INTO revenue_data (tenant_id, customer_id, amount, date, segment, source)
      VALUES (${t}, ${a}, ${r}, ${n}, ${i}, ${l})
      RETURNING *
    `).rows[0]}static async getTasks(t,e={}){await this.setTenantContext(t);let a=(0,s.ll)`
      SELECT * FROM tasks 
      WHERE tenant_id = ${t}
    `;return e.status&&"all"!==e.status&&(a=(0,s.ll)`${a} AND status = ${e.status}`),void 0!==e.ai_generated&&(a=(0,s.ll)`${a} AND ai_generated = ${e.ai_generated}`),a=(0,s.ll)`${a} ORDER BY 
      CASE priority 
        WHEN 'high' THEN 1 
        WHEN 'medium' THEN 2 
        WHEN 'low' THEN 3 
      END, 
      created_at DESC`,(await a).rows}static async createTask(t,e){await this.setTenantContext(t);let{title:a,description:r,assignee:n,status:i="pending",priority:l="medium",due_date:E,ai_generated:o=!1}=e;return(await (0,s.ll)`
      INSERT INTO tasks (tenant_id, title, description, assignee, status, priority, due_date, ai_generated)
      VALUES (${t}, ${a}, ${r}, ${n}, ${i}, ${l}, ${E}, ${o})
      RETURNING *
    `).rows[0]}static async addToWaitlist(t){let{full_name:e,work_email:a,company:r,role:n,industry:i}=t;try{return(await (0,s.ll)`
        INSERT INTO waitlist (full_name, work_email, company, role, industry)
        VALUES (${e}, ${a}, ${r}, ${n}, ${i})
        RETURNING *
      `).rows[0]}catch(t){if(t.message.includes("unique constraint"))throw Error("Email already registered");throw t}}static async getWaitlistEntries(){return(await (0,s.ll)`
      SELECT * FROM waitlist 
      ORDER BY created_at DESC
    `).rows}static async initializeTenant(t,e){try{for(let a of(await (0,s.ll)`
        INSERT INTO tenants (tenant_id, name, subdomain, plan)
        VALUES (${t}, ${e.name}, ${e.subdomain||t}, ${e.plan||"starter"})
        ON CONFLICT (tenant_id) DO NOTHING
      `,await this.setTenantContext(t),[{name:"John Smith",email:"john@example.com",company_name:"Example Corp",arr:5e4,health_score:85,churn_risk:15,segment:"mid-market"},{name:"Sarah Johnson",email:"sarah@demo.com",company_name:"Demo Inc",arr:12e4,health_score:92,churn_risk:8,segment:"enterprise"}]))await this.createCustomer(t,a);return console.log(`✅ Tenant ${t} initialized with sample data`),!0}catch(e){throw console.error(`❌ Error initializing tenant ${t}:`,e),e}}static async getTenant(t){return(await (0,s.ll)`
      SELECT * FROM tenants WHERE tenant_id = ${t}
    `).rows[0]}static extractTenantId(t){let e=t.headers.get("x-tenant-id");if(e)return e;let a=t.headers.get("host");if(a){let t=a.split(".")[0],e={"urban-ark":"urban_ark",caalvert:"caalvert_enterprises",brandme:"brandme_kenya"};if(e[t])return e[t]}return"demo_tenant"}}r.initializeDatabase().catch(console.error)},91645:t=>{"use strict";t.exports=require("net")},94735:t=>{"use strict";t.exports=require("events")},96487:()=>{}};var e=require("../../../webpack-runtime.js");e.C(t);var a=t=>e(e.s=t),s=e.X(0,[447,580,376],()=>a(19225));module.exports=s})();